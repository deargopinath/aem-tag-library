import React from 'react';
import styled from '@emotion/styled';

const Footer: React.FC = () => {
  return (
    <FooterContainer>
      GraphQL Client with React and Typescript
    </FooterContainer>
  );
};

export default Footer;

const FooterContainer = styled.div({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  color: '#ffffff',
  marginTop: 30,
  height: 20,
  padding: 20,
  backgroundColor: '#3c1053',
});

