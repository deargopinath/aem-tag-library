# NatWest Insights - client

The final state of the `client` code after finishing the Odyssey Lift-off II course.
