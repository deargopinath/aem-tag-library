##### tests/test_api.py #####
import sys
import os

# Ensure the project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))


import pytest
import sqlite3
import json
from fastapi.testclient import TestClient
from main import app
from setup_test_data import setup_test_data

# Setup the test client
client = TestClient(app)

@pytest.fixture(scope="module", autouse=True)
def setup_database():
    print("Setup test data before running tests.")
    setup_test_data()
    yield

def test_quotes_data_loaded():
    """Ensure quotes data is correctly inserted into the database."""
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM QUOTES_TABLE")
    row_count = cursor.fetchone()[0]
    
    conn.close()
    
    assert row_count > 0, "Fire risk test data should be loaded into the database."

def test_api_quotes():
    print("Test the /api/quotes endpoint.")
    response = client.get("/api/quotes")
    assert response.status_code == 200, "API should return 200 OK"

    json_response = response.json()
    assert isinstance(json_response, list), "Response should be a list"

    for item in json_response:
        assert "id" in item
        assert "quote" in item
        assert "story" in item


def test_api_invalid_endpoint():
    """Test an invalid endpoint to ensure proper error handling."""
    response = client.get("/api/invalidEndpoint")
    assert response.status_code == 404, "Invalid API route should return 404"

def test_database_connection():
    """Ensure the database connection is working."""
    try:
        conn = sqlite3.connect("db.sqlite3")
        conn.execute("SELECT 1")
        conn.close()
    except Exception as e:
        pytest.fail(f"Database connection failed: {e}")
