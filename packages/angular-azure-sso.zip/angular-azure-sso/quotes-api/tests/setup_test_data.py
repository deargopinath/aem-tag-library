import sqlite3
import pandas


def setup_test_data():
    # Table definitions
    table_defs = {
        "quotes": "id int, quote varchar, story varchar"
    }

    # Connect to local DB
    db_connection = sqlite3.connect("db.sqlite3")
    db_cmd = db_connection.cursor()

    # Delete and recreate mock data
    for key in table_defs.keys():
        table = key.upper() + "_TABLE"
        db_cmd.execute("DROP TABLE IF EXISTS " + table)
        db_cmd.execute("CREATE TABLE " + table + " (" + table_defs[key] + ")")
        table_data = pandas.read_csv("tests/data/" + key + ".csv")
        table_data.to_sql(table, db_connection, if_exists="replace", index=False)
        print(table + " was created successfully.")

    # Save and exit
    db_connection.commit()
    db_connection.close()


if __name__ == "__main__":
    setup_test_data()
