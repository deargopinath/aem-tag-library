from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from database import SessionLocal
from models import QuotesModel
from schemas import Quote
from typing import List, Optional

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def is_valid(token: str):
    """Decode and validate the JWT."""
    if not token or len(token) < 5:
        print("Invalid token")
        return False
    return True

@router.get("/api/quotes", response_model=List[Quote])
def get_quotes(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):

    # Check if Authorization header exists
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")

    # Extract token from "Bearer <token>"
    token = authorization.replace("Bearer ", "").strip()

    if not is_valid(token):
        raise HTTPException(status_code=401, detail="Invalid token")

    try:
        quotes = db.query(QuotesModel).all()
        return quotes
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")

