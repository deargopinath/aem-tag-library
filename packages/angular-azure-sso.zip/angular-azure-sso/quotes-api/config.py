import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./db.sqlite3")
    DEBUG = os.getenv("DEBUG", False)
    ALLOWED_HOSTS = os.getenv("ALLOWED_HOSTS", "*").split(",")
    QUOTES_TABLE = "QUOTES_TABLE"

settings = Settings()