# QuotesAPI - FastAPI Version

## Overview

This is a FastAPI-based implementation of the QuotesAPI. 
It provides an endpoint to fetch quotes data from a database.

## Features

- FastAPI framework for high-performance API handling
- SQLAlchemy ORM for database interactions
- Pydantic models for request/response validation
- Dockerized deployment support
- Environment-based configuration
- Integration with Azure Key Vault for secret management

## Requirements

- Python 3.9+
- FastAPI
- Uvicorn
- SQLAlchemy
- Pydantic v2
- Alembic (for database migrations)
- Docker (optional for containerized deployment)

## Installation & Setup

### 1. Clone the Repository

```sh
git clone <repository-url>
cd QuotesAPI
```

### 2. Create a Virtual Environment

```sh
python -m venv venv
source venv/bin/activate   # On macOS/Linux
venv\Scripts\activate      # On Windows
```

### 3. Install Dependencies

```sh
pip install -r requirements.txt
```

### 4. Set Up Environment Variables

Create a `.env` file in the project root with the following:

```ini
DATABASE_URL=sqlite:///./db.sqlite3
DEBUG=True
ALLOWED_HOSTS=*
```

### 5. Run Database Migrations

```sh
alembic upgrade head
```

### 6. Start the API Server

```sh
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
or

```sh
python main.py
```


## API Endpoints

### 1. Get Quotes Data

**Endpoint:** `GET /api/quotes`

**Response:**

```json
[
  {
    "ID": 1,
    "Quote": "quote",
    "Story": "name of the story"
  }
]
```

## Running with Docker

### 1. Build the Docker Image

```sh
docker build -t quotesapi .
```

### 2. Run the Container

```sh
docker run -p 8000:8000 quotesapi
```

## Testing

Run the test suite with:

```sh
pytest --cov=.
```

## Access API Documentation

Once the server is running, visit:

- **Swagger UI:** [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **ReDoc:** [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

## License

This project is licensed under the MIT License.

