##### main.py #####

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import router
from database import Base, engine

from tests.setup_test_data import setup_test_data
setup_test_data()

app = FastAPI()

# CORS Middleware - Allows requests from all origins (Adjust as needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change this to specific domains if needed
    allow_credentials=True,
    allow_methods=["*"],  # Allows GET, POST, OPTIONS, etc.
    allow_headers=["*"],  # Allows Authorization and custom headers
)

app.include_router(router)

Base.metadata.create_all(bind=engine)

@app.get("/")
async def index():
    return {"message": "Hello! How are you doing?"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)