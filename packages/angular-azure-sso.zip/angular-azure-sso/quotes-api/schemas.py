##### schemas.py #####

from pydantic import BaseModel, ConfigDict

class Quote(BaseModel):
    id: int
    quote: str
    story: str

    class Config:
        model_config = ConfigDict(from_attributes=True)
