##### models.py #####

from sqlalchemy import Column, Integer, String
from database import Base
from config import settings

class QuotesModel(Base):
    __tablename__ = settings.QUOTES_TABLE

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    quote = Column(String, nullable=False)
    story = Column(String, nullable=False)

