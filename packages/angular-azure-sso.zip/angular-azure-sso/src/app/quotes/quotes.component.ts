import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { QUOTES_API } from 'src/environments/environment';

type QuoteType = {
  id: number,
  quote: string,
  story: string
}

@Component({
  selector: 'app-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.css']
})
export class QuotesComponent implements OnInit {
  profile!: string
  quotes!: QuoteType[]

  constructor(
    private http: HttpClient
  ) { }

  ngOnInit() {
    this.getProfile();
  }

  getProfile() {
    this.http.get(QUOTES_API)
      .subscribe(result => {
        this.profile = JSON.stringify(result);
        this.quotes = JSON.parse(this.profile);
      });
  }
}
