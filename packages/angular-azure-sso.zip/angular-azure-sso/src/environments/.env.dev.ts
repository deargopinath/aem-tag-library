import 'zone.js/plugins/zone-error';

export const environment = {
  production: false
};


export const APP_ID = 'f20654f5-fc87-402d-b64c-8cbda57056fe'
export const SSO_URL = 'https://login.microsoftonline.com/4db80b03-6d92-48a1-bc12-05c043d199c7'

export const LOGIN_REDIRECT = 'http://localhost:4200'
export const LOGOUT_REDIRECT = 'http://localhost:4200'

export const QUOTES_API = 'http://localhost:8000/api/quotes'
export const PROFILE_API = 'https://graph.microsoft.com/v1.0/me'
// export const PROFILE_API = 'http://localhost:8888/api/profile'
