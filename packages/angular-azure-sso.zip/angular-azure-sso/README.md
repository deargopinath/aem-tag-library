# angular-azure-sso
Angular app integrated with Azure Single Sign-on service

## Solution overview
```
+---------------+        +-----------------------+        +---------------+                           
|  Angular app  |        |  Azure Single Sign-on |        |  Secured API  |
|               |        |                       |        |               |
|  port# 4200   |        |  login.microsoft.com  |        |  port# 8000   |
+-------+-------+        +-----------+-----------+        +-------+-------+
        |                            |                            |        
        |      Step 1: Login         |                            |
        |  ----------------------->  |                            |
        |                            |                            |
        |      Step 2: Get token     |                            |
        |  <-----------------------  |                            |
        |                                                         |         
        |      Step 3: Attach token to the request                |
        |  ---------------------------------------------------->  |
        |                                                         |
        |      Step 4: Verify token and respond                   |
        |  <----------------------------------------------------  |
        |                                                         |    
```

## Pre-requisites
1. App registration in Azure
2. Nodejs 18
3. Angular 16


## Setup

### 1. [App registration in Azure](https://docs.microsoft.com/azure/active-directory/develop/scenario-spa-app-registration)

### 2. Configure SSO in the Angular app
> Copy **environment.ts** to **.env.dev.ts** and update SSO settings in **.env.dev.ts**

```
export const APP_ID = 'Azure Application ID shown in Azure portal'
export const SSO_URL = 'https://login.microsoftonline.com/' + 'Azure Tenant ID'
export const QUOTES_API = 'http://localhost:8000/'
export const LOGIN_REDIRECT = 'http://localhost:4200/'
export const LOGOUT_REDIRECT = 'http://localhost:4200/'
```

### 3. Start the API
```
> cd api
> node api.js
```

### 4. Build and verify Angular app
```
> npm install
> ng serve
```

> Open [http://localhost:4200](http://localhost:4200)
