# React UI for GraphQL end point of AEM content fragments


# GraphQL queries

## Get all blogs

```

query {
  insightsList {
    items {
      _path
      blog
      title
      category
      readingTime
      datePublished
      primaryImage {
        ... on ImageRef {
          _path
        }
      }
    }
  }
}
```


##  Get blogs by category

```
query ($category: String!) {
  insightsList(
    sort: "title ASC"
    filter: {category: {_expressions: [{value: $category, _ignoreCase: true}]}}
) {
    items {
      _path
      blog
      title
      category
      datePublished
      readingTime
      primaryImage {
        ... on ImageRef {
          _path
        }
      }
    }
  }
}

```


# Get blog details

```
query getInsightDetail($blog: String!) {
  insightsList(filter: {blog: {_expressions: [{value: $blog}]}}) {
    items {
      _path
      title
      category
      summary {
        html
        json
      }
      readingTime
      datePublished
      detail {
        html 
        json
      }
      primaryImage {
        ... on ImageRef {
          _path
          mimeType
          width
          height
        }
      }
    }
  }
}
```
