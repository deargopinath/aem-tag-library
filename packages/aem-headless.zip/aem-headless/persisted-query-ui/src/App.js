import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ScrollToTop from "./utils/scrollToTop";
import Home from "./components/Home";
import InsightDetail from "./components/InsightDetail";
import "./designs/main.css";
import "./designs/app.scss";


function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="App">
			<section className="herobanner " name="Hero Banner">
				<div className="container-fluid herobanner__imagewrapper herobanner__illust ">
					<div className="herobanner__imagecontainer">
						<div className="herobanner__image-content hero-wrapper-dmm ">
							<div className="inner-grid short_hero  photographic_hero  ">
								<div className="photographic_div">									
									<div className="comp-img-generic">
										<div className="adaptive-image-wrapper" data-picture="" data-picture-width="1135" data-picture-height="535" data-role="presentation">
										</div>
									</div>
								</div>
								<div className="content-wrapper no-img-authored hide_cta_area photographic_layout   ">
									<div className="title-wrapper">
											<div className="credit_card_title ">
												<span className="text-comp">Intelligently different thinking</span>
											</div>
										<div className="header_one--title ">
											<h1 className="title-comp">Insight and comment from NatWest</h1>
										</div>
									</div>
									<div className="cta-wrapper">
									</div>
								</div>
							</div>
						</div>			
					</div>
				</div>
			</section>
        <Routes>
          <Route path='/insights/:blog' element={<InsightDetail/>}/>
          <Route path="/" element={<Home />}/>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
