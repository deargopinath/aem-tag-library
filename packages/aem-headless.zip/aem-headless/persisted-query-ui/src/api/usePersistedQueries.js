import { useEffect, useState } from "react";
import aemHeadlessClient from "./aemHeadlessClient";

async function fetchPersistedQuery(persistedQueryName, queryParameters) {
  let data;
  let err;

  try {
    const response = await aemHeadlessClient.runPersistedQuery(
      persistedQueryName,
      queryParameters
    );
    data = response?.data;
  } catch (e) {
    err = e.toJSON()
    console.error(err);
  }
  return { data, err };
}


export function useBlogSummary(insightCategory) {

  const [insights, setInsights] = useState(null);
  const [errors, setErrors] = useState(null);

  useEffect(() => {
    async function fetchData() {
      let response;
      if (insightCategory) {
        const queryParameters = { category: insightCategory };
        response = await fetchPersistedQuery("insight-cf/insights-by-category", queryParameters);
      } else {
        response = await fetchPersistedQuery("insight-cf/insights-all");
      }
      setInsights(response.data?.insightsList?.items);
      setErrors(response.err);
    }
    // Call the internal fetchData() as per React best practices
    fetchData();
  }, [insightCategory]);
  return { insights, errors };
}


export function useBlogDetail(blogName) {
  const [insight, setInsight] = useState(null);
  const [references, setReferences] = useState(null);
  const [errors, setErrors] = useState(null);

  useEffect(() => {
    async function fetchData() {

      let response;
      const queryParameters = { blog: blogName };
      response = await fetchPersistedQuery(
        "insight-cf/insight-detail",
        queryParameters
      );
      
      if (response.err) {
        setErrors(response.err);
      } else if (response.data?.insightsList?.items?.length === 1) {
        setInsight(response.data.insightsList.items[0]);
        setReferences(response.data.insightsList._references);
      } else {
        setErrors(`Cannot find Insight with blog: ${blogName}`);
      }
    }
    // Call the internal fetchData() as per React best practices
    fetchData();
  }, [blogName]);
  return { insight, references, errors };
}