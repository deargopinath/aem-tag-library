import { Link } from "react-router-dom";
import { useBlogSummary } from "../api/usePersistedQueries";
import Error from "./Error";
import '../designs/insights.scss';
import Loading from './Loading';

function Insights({ insightCategory }) {

    const { insights, error } = useBlogSummary(insightCategory);

    // Handle error and loading conditions
    if (error) {
        return <Error errorMessage={error} />;
    } else if (!insights) {
        return <Loading />;
    }

    return (
        <div className="insights">
            <ul className="insight-items">
                {insights.map((insight, index) => {
                    return <InsightListItem key={index} {...insight} />
                })}
            </ul>
        </div>

    );
}

// Render individual Insight item
function InsightListItem({ title, blog, primaryImage, datePublished, readingTime }) {
    // Must have title, path, and image
    //if (!title || !blog || !primaryImage) {
    //    return null;
    //}
    /*
    "_path": "/content/dam/insight-cf/en/insights/continued-growth-in-renewables-and-energy",
    "blog": "renewables-and-energy",
    "title": " Continued growth in renewables and energy sectors despite lower overall infrastructure investments",
    "category": "Sustainability",
    "readingTime": 4,
    "datePublished": "30 Nov 2023",
    "primaryImage": {
        "_path": "/content/dam/insight-cf/en/insights/private-finance-sustainability-monthly-november-2023.jpg"
    }
    */

    return (
        <li className="insight-item">
            <Link to={`/insights/${blog}`}>
                <img className="insight-item-image" src={primaryImage._path}
                    alt={title} />
            </Link>
            <div className="insight-item-length-readingTime">
                <div className="insight-item-length">{datePublished}</div>
                <div className="insight-item-readingTime">
                    {readingTime} min. read
                </div>
            </div>
            <div className="insight-item-title">{title}</div>
        </li>
    );
}

export default Insights;