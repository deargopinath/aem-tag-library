import { Link, useParams } from "react-router-dom";
import { useBlogDetail } from "../api/usePersistedQueries";
import backIcon from '../images/icon-close.svg';
import { mapJsonRichText } from '../utils/renderRichText';
import '../designs/insight-detail.scss';
import Error from "./Error";
import Loading from "./Loading";

function InsightDetail() {

    const { blog } = useParams();

    // Query AEM for the Adventures's details, using the `blog`
    const { insight, references, error } = useBlogDetail(blog);

    // Handle error and loading conditions
    if (error) {
        return <Error errorMessage={error} />;
    } else if (!insight) {
        return <Loading />;
    }

    return (<div className="insight-detail">
        <Link className="insight-detail-close-button"  to="/">
            <img className="Backbutton-icon" src={backIcon} alt="Return" />
        </Link>
        <AdventureDetailRender {...insight} references={references} />
    </div>);

}

function AdventureDetailRender({ title,
    primaryImage,
    category,
    datePublished,
    readingTime,
    detail,
    summary,
    references,  }) {

    return (
        <>
            <h1 className="insight-detail-title">{title}</h1>
            <div className="insight-detail-info">
                <div className="insight-detail-info-label">Category</div>
                <div className="insight-detail-info-description">{category}</div>
                <div className="insight-detail-info-label">Published on</div>
                <div className="insight-detail-info-description">{datePublished}</div>
                <div className="insight-detail-info-label">Length</div>
                <div className="insight-detail-info-description">{readingTime} min. read</div>
            </div>
            <div className="insight-detail-content">
                <img className="insight-detail-primaryimage"
                    src={primaryImage._path} alt={title} />
                <div>{mapJsonRichText(summary.json, customRenderOptions(references))}</div>
                <h2>Detail</h2>
                <hr />
                {/*<div className="insight-detail-itinerary">{mapJsonRichText(detail.json)}</div>*/}
                <div className="insight-detail-itinerary" dangerouslySetInnerHTML={{__html: detail.html}}></div>
            </div>
        </>
    );
}

/**
 * Example of using a custom render for in-line references in a multi line field
 */
function customRenderOptions(references) {

    const renderReference = {
        // node contains merged properties of the in-line reference and _references object
        'ImageRef': (node) => {
            // when __typename === ImageRef
            return <img src={node._path} alt={'in-line reference'} />
        },
        'AdventureModel': (node) => {
            // when __typename === AdventureModel
            return <Link to={`/insight:${node.blog}`}>{`${node.title}: ${node.readingTime}`}</Link>;
        }
    };

    return {
        nodeMap: {
            'reference': (node, children) => {

                // variable for reference in _references object
                let reference;

                // asset reference
                if (references && node.data.path) {
                    // find reference based on path
                    reference = references.find(ref => ref._path === node.data.path);
                }
                // Fragment Reference
                if (references && node.data.href) {
                    // find in-line reference within _references array based on href and _path properties
                    reference = references.find(ref => ref._path === node.data.href);
                }

                // if reference found return render method of it
                return reference ? renderReference[reference.__typename]({ ...reference, ...node }) : null;
            }
        },
    };
}

export default InsightDetail;
