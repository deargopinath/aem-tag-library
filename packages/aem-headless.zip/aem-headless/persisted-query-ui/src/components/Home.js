import { useState } from 'react';
import Insights from './Insights';

function Home() {
    const [insightCategory, setInsightCategory] = useState('');
    return (
      <div className="Home">
        <h2>Explore our articles and market research whitepapers</h2>
        <div className="insight-nav">
          <button onClick={() => setInsightCategory('Finance')}>Finance</button>
          <button onClick={() => setInsightCategory('Technology')}>Technology</button>
          <button onClick={() => setInsightCategory('Sustainability')}>Sustainability</button>
          <button onClick={() => setInsightCategory('')}>All</button>
        </div>
        <Insights insightCategory={insightCategory} />
    </div>
    );
}

export default Home;