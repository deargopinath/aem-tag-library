import '@testing-library/jest-dom/extend-expect';
process.env.REACT_APP_GRAPHQL_ENDPOINT = 'test'
