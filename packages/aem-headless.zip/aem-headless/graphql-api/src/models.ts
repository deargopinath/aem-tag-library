export type ContentFragment = {
  title: string
  elements: {
    category: { 
      value: string 
    }
    primaryImage: { 
      value: string 
    }
    title: { 
      value: string 
    }
    blog: { 
      value: string 
    }
    summary: { 
      value: string 
    }
    detail: { 
      value: string 
    }
    readingTime: { 
      value: number 
    }
    datePublished: { 
      value: string 
    }
  }
}

export type CFList = {
  items: Array<ContentFragment>
}

export type BlogModel = {
  id: string
  category: string
  title: string
  image: string
  summary: string
  detail: string
  readingTime: number
  datePublished: string
}

