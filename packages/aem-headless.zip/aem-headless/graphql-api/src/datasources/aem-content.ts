import { RESTDataSource } from "@apollo/datasource-rest";
import { CFList } from "../models";

export class BlogAPI extends RESTDataSource {
  baseURL = 'http://localhost:4503/content/insight-xf/en/api/blogs/jcr:content/root/'

  getBlogs() {
    return this.get<CFList>("contentfragmentlist.model.json")
      .then(blogs => blogs.items.map(item => (
          {
            id: item.elements.blog.value,
            category: item.elements.category.value,
            title: item.elements.title.value,
            image: item.elements.primaryImage.value,
            summary: item.elements.summary.value,
            detail: item.elements.detail.value,
            readingTime: item.elements.readingTime.value,
            datePublished: item.elements.datePublished.value
          }
        ))
      ).catch(err => {
        console.log(err)
        return []
      });
  }
}
