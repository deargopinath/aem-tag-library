import gql from "graphql-tag";

export const typeDefs = gql`

type Blog {
  id: ID!
  category: String
  title: String!
  image: String
  summary: String
  detail: String
  readingTime: Int
  datePublished: String
}

type Query {
  blogs(category: String): [Blog!]!
}

`;
