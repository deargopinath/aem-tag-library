import { BlogAPI } from "./datasources/aem-content";

export type DataSourceContext = {
  dataSources: {
    blogAPI: BlogAPI;
  };
}
