import { Resolvers } from "./types";

export const resolvers: Resolvers = {
  Query: {
    // Filter blogs by category
    blogs: (_, { category }, { dataSources }) => (
      dataSources.blogAPI.getBlogs()
        .then( allBlogs => ( 
          category 
          ? allBlogs.filter(blog => blog.category === category) 
          : allBlogs
      ))
    )
  },
};
