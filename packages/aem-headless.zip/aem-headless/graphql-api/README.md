# NatWest Insights - server

The final state of the `server` code after finishing Odyssey Lift-off II course.
