import { Layout } from "../components";
import QueryResult from "../components/query-result";
import { gql } from "../__generated__";
import { useQuery } from "@apollo/client";
import BlogCard from "../containers/blog-card";

/** Get all blogs */
export const ALL_BLOGS = gql(`
  query GetAllInsights {
    blogs {
      id
      category
      title
      image
      summary
      detail
      readingTime
      datePublished
    }
  }
`);

const Blogs = () => {
  const { loading, error, data } = useQuery(ALL_BLOGS);

  return (
    <Layout grid>
      <QueryResult error={error} loading={loading} data={data}>
        {data?.blogs?.map((track) => (
          <BlogCard key={track.id} track={track} />
        ))}
      </QueryResult>
    </Layout>
  );
};

export default Blogs;
