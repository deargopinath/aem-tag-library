// this adds custom jest matchers from jest-dom
import '@testing-library/jest-dom/extend-expect';
import { InMemoryCache } from '@apollo/client';
import { renderApolloWithRouter, cleanup, waitForElement } from '../../utils/test-utils';
import Blogs, { ALL_BLOGS } from '../blog-queries';

const mockBlog = {
  id: 'c_0',
  title: 'Nap, the hard way',
  thumbnail:
    'https://images.unsplash.com/photo-1542403810-74c578300013?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjExNzA0OH0',
  length: 1420,
  datePublished: 6,
  author: {
    name: 'Cheshire Cat',
    photo:
      'https://images.unsplash.com/photo-1593627010886-d34828365da7?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjExNzA0OH0',
  },
};

describe('Blogs Page', () => {
  afterEach(cleanup);
  const cache = new InMemoryCache({ addTypename: false });

  it('renders tracks', async () => {
    const mocks = [
      {
        request: { query: ALL_BLOGS },
        result: {
          data: {
            blogs: [mockBlog],
          },
        },
      },
    ];

    const { getByText } = await renderApolloWithRouter(<Blogs />, {
      mocks,
      cache,
    });

    await waitForElement(() => getByText(/nap, the hard way/i));
  });
});
