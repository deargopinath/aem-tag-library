import { BrowserRouter, Routes, Route } from "react-router-dom";
/** importing our pages */
import Blogs from "./blog-queries";

export default function Pages() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Blogs />} path="/" />
      </Routes>
    </BrowserRouter>
  );
}
